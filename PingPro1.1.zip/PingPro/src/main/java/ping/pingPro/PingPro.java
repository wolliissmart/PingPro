//PingPro
//This Minecraft Plugin displays the ping in game to players.
//It is written by Liam Stocker.
//Current version: 1.1

package ping.pingPro;

import org.bukkit.command.Command;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.plugin.java.JavaPlugin;

public final class PingPro extends JavaPlugin {

    @Override
    public void onEnable() {
        //Plugin initialisation.
        getLogger().info("PingPro wird initalisiert");
    }

    @Override
    public void onDisable() {
        // Plugin shutdown
        getLogger().info("PingPro wird beendet.");
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (command.getName().equalsIgnoreCase("ping")) {

            if (args.length == 0) {

                if (!(sender instanceof Player)) {
                    sender.sendMessage("Nur für Spieler verfügbar.");
                    return true;
                }

                if (!sender.hasPermission("pingpro.ping")) {
                    sender.sendMessage("§cKeine Rechte für die Durchführung der Aktion verfügbar.");
                    getLogger().warning("Player " + sender.getName() + " has not enough permissions to get his ping");
                    return true;
                }

                Player player = (Player) sender;
                int ping = player.getPing();
                player.sendMessage("§aDein Ping ist: §e" + ping + " §ams");
                getLogger().info("Player " + player.getName() + " requested his ping. His ping is: " + ping + " ms.");
                return true;
            }

            if (args.length == 1 && args[0].equalsIgnoreCase("info")) {
                getLogger().info("Ping-Plugin written by Liam Stocker. Available on github.");
                sender.sendMessage("Ping-Plugin written by Liam Stocker. Available on github.");
                return true;
            }

            if (args.length == 1 && sender.hasPermission("pingpro.ping.get")) {

                Player target = getServer().getPlayer(args[0]);

                if (target == null) {
                    sender.sendMessage("§cSpieler nicht gefunden!");
                    getLogger().info("Player not found.");
                    return true;
                }

                if (!(sender instanceof Player)) {
                    int ping = target.getPing();
                    getLogger().info("The ping from " + target.getName() + " is " + ping + " ms.");
                    return true;
                }

                int ping = target.getPing();
                sender.sendMessage("§aPing von §e" + target.getName() + ": " + ping + " §ams");
                getLogger().info("Player " + sender.getName() + " requested the ping from " + target.getName() + ".");
                return true;
            }

            if (args.length == 1 && !sender.hasPermission("pingpro.ping.get")) {

                Player target = getServer().getPlayer(args[0]);

                if (target == null) {
                    sender.sendMessage("§cSpieler nicht gefunden!");
                    getLogger().info("Player not found.");
                    return true;
                }

                if (!(sender instanceof Player)) {
                    int ping = target.getPing();
                    getLogger().info("The ping from " + target.getName() + " is " + ping + " ms.");
                    return true;
                }

                sender.sendMessage("§cKeine Rechte für die Durchführung der Aktion vorhanden.");
                getLogger().warning("Player " + sender.getName() + " has not enough rights to get the ping from another player.");
                return true;

            }

            if (args.length > 1) {
                return false;
            }

        }

        return false;
    }
}